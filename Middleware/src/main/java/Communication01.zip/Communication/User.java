package Communication;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class User extends JFrame {
    private static String id;
    private static Sender sender;
    private static Receiver receiver;

    public User(){
    }

    public static void main(String[] args) {
        sender = new Sender();
        Random random = new Random();
        id = Integer.toString(random.nextInt(100000));
        JTextArea messageReceived = new JTextArea();
        messageReceived.setBounds(20, 80, 360, 150);
        receiver = new Receiver(id, messageReceived);
        receiver.start();
        JFrame f = new JFrame("MiddleTest" + id);
        f.setSize(400, 300);//设置容器尺寸
        f.setLocation(200, 200);//设置容器位置
        f.setLayout(null);//设置布局。
        JLabel idLabel = new JLabel();
        idLabel.setText("ID: " + id);
        System.out.println(id);
        idLabel.setBounds(20, 10, 100, 30);

        JTextField receiverId = new JTextField();
        receiverId.setBounds(20, 40, 100, 30);

        JTextField message = new JTextField();
        message.setBounds(140, 40, 160, 30);

        JButton sendButton = new JButton("发送");
        sendButton.setBounds(320, 40, 60, 30);//设置按钮在容器中的位置
        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 对话框
                if(receiverId.getText() == null){
                    JOptionPane.showMessageDialog(null, "发送对象不能为空！");
                    return;
                }
                if(message.getText() == null){
                    JOptionPane.showMessageDialog(null, "发送内容不能为空！");
                    return;
                }
                sender.send(id, receiverId.getText(), message.getText());
            }
        });

        f.add(idLabel);
        f.add(receiverId);
        f.add(message);
        f.add(messageReceived);
        f.add(sendButton);//将按钮加在容器上
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//界面关闭后程序结束

        f.setVisible(true);//界面可视化
    }
}
