package Communication;

/**
 * 程序启动入口
 * @author snow create 2021/03/23 20:44
 *            modified 2021/03/23 23:13
 */
public class Client {
    public static void main(String[] args){
        User user = new User("123");
    }
}
