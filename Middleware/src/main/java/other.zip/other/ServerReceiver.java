package other;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;
import javax.swing.*;

public class ServerReceiver extends Thread{
    private String id;
    private JTextArea textArea;
    private ConnectionFactory connectionFactory;
    private Connection connection;
    private Session session;
    private Destination destination;
    private MessageConsumer consumer;
    private ServerMessageHandler serverMessageHandler;
    public ServerReceiver(String id, JTextArea textArea){
        this.id = id;
        this.textArea = textArea;
        this.serverMessageHandler = new ServerMessageHandler(id);
        this.connectionFactory = new ActiveMQConnectionFactory(
                ActiveMQConnection.DEFAULT_USER,
                ActiveMQConnection.DEFAULT_PASSWORD,
                "tcp://localhost:61616");
    }

    @Override
    public void run() {
        try {
            connection = connectionFactory.createConnection();
            connection.start();
            session = connection.createSession(Boolean.FALSE,
                    Session.AUTO_ACKNOWLEDGE);
            destination = session.createQueue("S_" + this.id);
            consumer = session.createConsumer(destination);
            while (true) {
                TextMessage message = (TextMessage) consumer.receive(500000);
                if (null != message) {
                    this.textArea.append(serverMessageHandler.processMessage(message.getText()));
                    System.out.println("收到消息: " + message.getText());
                } else {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (null != connection)
                    connection.close();
            } catch (Throwable ignore) {
            }
        }

    }
}
