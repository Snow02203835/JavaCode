package other;

public enum MessageType {
    USER_LOGIN("0001", "用户登录"),
    USER_LOGIN_SUCCEED("002", "用户登录成功"),
    USER_LOGIN_FAILED("003", "用户登录失败");
    private String type;
    private String message;
    MessageType(String type, String msg){
        this.type = type;
        this.message = msg;
    }

    public String getType() {
        return type;
    }

    public String getMessage() {
        return message;
    }
}
