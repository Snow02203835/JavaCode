package other;

public class Server {
    public static void main(String[] args) {
        Service service = new Service();
    }
}
