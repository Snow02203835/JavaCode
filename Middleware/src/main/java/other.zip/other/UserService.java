package other;

import java.time.LocalDateTime;

public class UserService {
    public boolean userLogin(String userName, String password){
        return true;
    }
}
