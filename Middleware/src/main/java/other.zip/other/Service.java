package other;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Service extends JFrame {
    private final String id = "3835";

    private ServerReceiver receiver;

    private JFrame window;
    private JButton clearMessage;
    private JTextArea messageViewer;
    public Service(){
        messageViewer = new JTextArea();
        clearMessage = new JButton("清除消息");
        receiver = new ServerReceiver(id, messageViewer);
        receiver.start();
        window = new JFrame("服务端");
        window.setLayout(null);
        window.setSize(400,600);
        window.setLocationRelativeTo(null);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        clearMessage.setBounds(280, 530, 100, 30);
        clearMessage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                messageViewer.setText("");
            }
        });
        messageViewer.setBounds(5, 5, 375, 520);

        window.add(clearMessage);
        window.add(messageViewer);
        window.setVisible(true);
    }
}
