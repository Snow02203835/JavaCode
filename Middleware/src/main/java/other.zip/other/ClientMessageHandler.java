package other;

import Communication.Sender;
import other.MessageType;

import java.time.format.DateTimeFormatter;

public class ClientMessageHandler {
    private String id;
    private Sender sender;
    private DateTimeFormatter dateTimeFormatter;
    public ClientMessageHandler(String id){
        this.id = id;
        sender = new Sender();
        this.dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss");
    }
    String processMessage(String message){
        String messageType = message.substring(0, 4);
        String messageContent = message.substring(4);
        System.out.println("MessageType: " + messageType);
        System.out.println("MessageContent:" + messageContent);
        if(messageType.equals(MessageType.USER_LOGIN_SUCCEED.getType())){
            return "";
        }
        else if(messageType.equals(MessageType.USER_LOGIN_FAILED.getType())){
            return "";
        }
        return null;
    }
}
