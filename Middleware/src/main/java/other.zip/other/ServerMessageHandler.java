package other;

import Communication.Sender;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class ServerMessageHandler {
    private String id;
    private Sender sender;
    private UserService userService;
    private DateTimeFormatter dateTimeFormatter;
    public ServerMessageHandler(String id){
        this.id = id;
        sender = new Sender();
        userService = new UserService();
        this.dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss");
    }
    String processMessage(String message){
        String messageType = message.substring(0, 4);
        String messageContent = message.substring(4);
        System.out.println("MessageType: " + messageType);
        System.out.println("MessageContent:" + messageContent);
        if(messageType.equals(MessageType.USER_LOGIN.getType())){
            return userLogin(messageContent);
        }
        return null;
    }
    String userLogin(String message){
        String[] user = message.split("@password@");
        if(userService.userLogin(user[0], user[1])){
            sender.send(id, user[0], "loginSucceed");
            return "UserLogin: '" + user[0] + "' Successfully login at " + getNow() + ".\n";
        }
        else{
            sender.send(id, user[0], "loginFailed");
            return "UserLogin: '" + user[0] + "' try login at " + getNow() + " but failed!\n";
        }
    }
    String getNow(){
        return LocalDateTime.now().format(dateTimeFormatter);
    }
}
