package other;

public class UserDao {
}
