package other;

import Communication.Sender;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/**
 * 用户登录界面，暂时弃用
 * @author snow create 2021/03/23 21:34
 *            modified 2021/03/23 23:12
 */
public class Login extends JFrame
{
    JFrame window;
    JTextField userName;
    JTextField password;
    JButton Login;


    public Login()
    {
        window = new JFrame ("登陆界面");
        window.setLayout(null);
        window.setSize(400,300);
        window.setLocationRelativeTo(null);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        window.setLayout(null);
        window.setResizable(false);

        JLabel username_label = new JLabel("用户名");
        username_label.setBounds(30,30,100,30);
        window.add(username_label);

        userName = new JTextField();
        userName.setBounds(100,30,240,30);
        window.add(userName);

        JLabel password_label = new JLabel("密码");
        password_label.setBounds(30,100,100,30);
        window.add(password_label);

        password = new JPasswordField();
        password.setBounds(100,100,240,30);
        window.add(password);

        Login = new JButton("登陆");
        Login.setBounds(170,180, 60,30);
        window.add(Login);

        window.setVisible(true);

        Login.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                String message = MessageType.USER_LOGIN.getType() + userName.getText() + "@password@" + password.getText();
                Sender sender = new Sender();
                sender.send(message);
            }
        });
    }


}
