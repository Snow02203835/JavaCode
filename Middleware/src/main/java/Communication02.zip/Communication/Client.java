package Communication;

public class Client {
    public static void main(String[] args){
//        Login login = new Login();
        User user = new User("123");
    }
}
