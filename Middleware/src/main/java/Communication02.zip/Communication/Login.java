package Communication;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.*;

public class Login extends JFrame
{
    private String username;
    private String password;

    JFrame window;
    JTextField user;
    JTextField pwd;
    JButton Login;


    public Login()
    {
        window = new JFrame ("登陆界面");
        window.setLayout(null);
        window.setSize(400,300);
        window.setLocationRelativeTo(null);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//closs

        window.setLayout(null);
        window.setResizable(false);

        JLabel username_label = new JLabel("用户名");
        username_label.setBounds(30,30,100,30);
        window.add(username_label);

        user = new JTextField();
        user.setBounds(100,30,240,30);
        window.add(user);

        JLabel password_label = new JLabel("密码");
        password_label.setBounds(30,100,100,30);
        window.add(password_label);

        pwd = new JPasswordField();
        pwd.setBounds(100,100,240,30);
        window.add(pwd);

        Login = new JButton("登陆");
        Login.setBounds(170,180, 60,30);
        window.add(Login);

        window.setVisible(true);

        this.username=user.getName();

        Login.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                String name=user.getText();
                String password=pwd.getText();
                if(password.equals("123"))
                {
                    System.out.println("登陆成功");
                    User c1 = new User(name);
                    window.setVisible(false);
                }
                else
                {
                    System.out.println("密码错误");
                }
            }
        });
    }


}
